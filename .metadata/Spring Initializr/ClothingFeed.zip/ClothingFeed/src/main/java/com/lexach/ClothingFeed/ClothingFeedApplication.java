package com.lexach.ClothingFeed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClothingFeedApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClothingFeedApplication.class, args);
	}
}
